const http=require('http'),fs=require('fs'),path=require('path');
const dist=path.resolve(__dirname,'dist');
http.createServer((req,res)=>{try{const n=decodeURIComponent(new URL(req.url,'http://localhost').pathname),f=path.resolve(dist,'.'+(n==='/'?'/index.html':n));if(!f.startsWith(dist+path.sep)){res.writeHead(403);return res.end()};const body=fs.readFileSync(f);res.writeHead(200,{'Cache-Control':'no-store','Content-Type':({'.html':'text/html','.js':'text/javascript','.css':'text/css','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'})[path.extname(f)]||'application/octet-stream'});res.end(body)}catch(e){res.writeHead(404);res.end('Not found')}}).listen(4330,'127.0.0.1',()=>console.log('Local Skyblade final candidate23 http://127.0.0.1:4330/'));

