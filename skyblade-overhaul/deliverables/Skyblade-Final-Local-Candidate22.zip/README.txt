Darren: Skyblade Hunt - Final Local Candidate22
Candidate21 application and accepted Chomp/Stormbelly + SkyDrake22 reduced weight repair.
Publication held. This package is not deployed to the live Site.

Extract into a new folder. With Node.js installed, open a terminal there and run:
node serve.cjs
Open http://127.0.0.1:4329/ in a separate browser profile for isolated saves.
Stop with Ctrl+C. The server binds only to this computer. Do not open index.html directly.

Only dist/assets/skydrake-rc15.glb differs from Candidate21.
No new content, engine, rig, clip, save-schema, HUD or control changes.
Candidate21 remains the tested rollback. Art likeness remains approximate.
Read Skyblade-Candidate22-Report.pdf for the comparison boards and practical limits.
The full-resolution SkyDrake22 experiments are not accepted and are not included.
Accepted full-resolution fallback remains SkyDrake15 in the Git project.
Editable reduced Blender source and the repair recipe remain in the Git project.
